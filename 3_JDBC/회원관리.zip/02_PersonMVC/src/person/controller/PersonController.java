package person.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import config.ServerInfo;

public class PersonController {
	
	// 리턴 타입이나 매개변수(파라미터) 자유롭게 변경 가능!
	/* 1. 드라이버 로딩
	 * 2. DB 연결
	 * 3. PrearedStatement - 쿼리
	 * 4. 쿼리 실행
	 * */
	public Connection link () {
		try {
			Class.forName(ServerInfo.DRIVER_NAME);
			return DriverManager.getConnection(ServerInfo.URL, ServerInfo.USER, ServerInfo.PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}	 
	}
	// person 테이블의 데이터 추가 - INSERT
	public String addPerson(int id ,String name, int age, String addr ) {
		
		try {
			Connection con = link();
			String query = "INSERT INTO person (id, name, age, addr ) VALUES (?, ?, ?, ?) ";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setInt(3, age);
			ps.setString(4, addr);
			ps.executeUpdate() ;
			return "ID : " + id + " 님 회원가입 완료";
		} catch (SQLException e) {
			
			return "ID : " + id + "이 이미 존재하여 회원가입이 불가능합니다.";
		}		
	}
	
	// person 테이블의 데이터 수정 - UPDATE
	public String updatePerson(int updateId, String name, int age, String addr) {
		try {
			Connection con = link();
			String query = "UPDATE person SET name = ? ,age = ?, addr = ? WHERE id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, name);
			ps.setInt(2, age);
			ps.setString(3, addr);
			ps.setInt(4, updateId);

			ps.executeUpdate() ;
			return  "ID : " + updateId + " 님 수정 완료";
		} catch (SQLException e) {
			
			return null;
		}
	}
	
	// person 테이블의 데이터 삭제 - DELETE
	public String removePerson(int deleteId) {
		try {
			Connection con = link();
			String query = "DELETE FROM person WHERE id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			
			ps.setInt(1, deleteId);
			
			ps.executeUpdate() ;
			return "ID : " + deleteId + " 님이 회원탈퇴 하셨습니다.";
		} catch (SQLException e) {
			
			return "탈퇴할 회원 ID : "+ deleteId +"를 찾지 못했습니다.";
		}
		
	}
	
	// person 테이블에 있는 데이터 전체 보여주기 - SELECT
	public String searchAllPerson() {
		try {
			Connection con = link();
			String query = "SELECT * FROM person";
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			String str = "" ;
			while(rs.next()) {// 다음꺼가 있는가
			int id = rs.getInt("id");
			String name = rs.getString("name");
			int age = rs.getInt("age");
			String addr = rs.getString("addr");
			str += "----회원 정보---- \nID : " + id + "\n이름 : " + name + "\n나이 : " + age + "\n주소 : " + addr + "\n";
			}
			
			return str;
		} catch (SQLException e) {
			
			return "현재 가입된 회원이 존재하지 않습니다.";
		}
	}
	
	// person 테이블에서 데이터 한개만 가져오기 - SELECT
	public String searchPerson(int idInfo) {
			String str = "" ;
		try {
			Connection con = link();
			String query = "SELECT * FROM person WHERE id = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setInt(1 ,idInfo);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
			int id = rs.getInt("id");
			String name = rs.getString("name");
			int age = rs.getInt("age");
			String addr = rs.getString("addr");
			str = "----ID : " + idInfo +" 님의 회원 정보---- \nID : " + id + "\n이름 : " + name + "\n나이 : " + age + "\n주소 : " + addr + "\n";
			}	
			return str;
		} catch (Exception e) {
			return idInfo + "에 해당하는 회원 정보가 없습니다.";
		}
		
	}

}
